# Security Policy

请勿在公开 Issue 中披露尚未修复的安全问题。可通过仓库维护者公开的 GitHub 联系方式私下报告，并提供复现步骤、影响范围和建议修复方案。

本项目不注入其他进程、不读取游戏内存，也不需要管理员权限。它调用 Windows GDI 的 Gamma Ramp API 修改当前会话的显示输出曲线。
