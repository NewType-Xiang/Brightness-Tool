# Contributing

欢迎提交 Issue 和 Pull Request。

1. Fork 仓库并创建功能分支。
2. 保持改动聚焦，并在 Windows 10/11 上测试。
3. 至少运行 `py -m py_compile shadow_boost.py`。
4. 涉及 Gamma Ramp 行为时，请同时测试开启、关闭、托盘退出和 `reset`。
5. 不要提交本地生成的 `settings.json`、缓存或虚拟环境。

