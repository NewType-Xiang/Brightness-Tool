#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
暗部增强（Shadow Boost）—— 用于游戏里看清阴暗角落

原理：修改显示器的 Gamma Ramp（显示输出查找表），抬高低亮度区间的亮度，
      高光基本不动。属于系统/显示层面的调整，不注入游戏进程、不改游戏内存。

用法：
  python shadow_boost.py apply --lift 0.10 --gamma 0.85     # 应用
  python shadow_boost.py reset                              # 还原
  python shadow_boost.py show                               # 查看当前曲线采样
  python shadow_boost.py gui                                # 图形界面（拖滑块实时生效）

界面说明：
  点右上角 × 会把工具收进右下角系统托盘，增强继续生效，不会退出；
  托盘图标双击 = 恢复面板，右键菜单 = 开关增强 / 还原并退出。
"""
import argparse, ctypes, json, os, sys
from ctypes import wintypes
from pathlib import Path

gdi32 = ctypes.WinDLL("gdi32")
user32 = ctypes.WinDLL("user32")

RAMP_SIZE = 256
DEFAULT_LIFT = 0.10
SETTINGS_PATH = Path(__file__).with_name("settings.json")


def load_lift_setting():
    """读取上次使用的强度；配置缺失或损坏时使用默认值。"""
    try:
        data = json.loads(SETTINGS_PATH.read_text(encoding="utf-8"))
        return clamp(float(data["lift"]), 0.04, 0.30)
    except (OSError, ValueError, TypeError, KeyError, json.JSONDecodeError):
        return DEFAULT_LIFT


def save_lift_setting(lift):
    """原子保存强度，避免程序意外中断留下半个配置文件。"""
    value = round(clamp(float(lift), 0.04, 0.30), 2)
    temp_path = SETTINGS_PATH.with_suffix(".json.tmp")
    temp_path.write_text(
        json.dumps({"lift": value}, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    os.replace(temp_path, SETTINGS_PATH)


class GammaRamp(ctypes.Structure):
    _fields_ = [("red", wintypes.WORD * RAMP_SIZE),
                ("green", wintypes.WORD * RAMP_SIZE),
                ("blue", wintypes.WORD * RAMP_SIZE)]


def list_displays():
    """返回 [(设备名 or None(主显示器)) ...]"""
    devs = []
    class DISPLAY_DEVICE(ctypes.Structure):
        _fields_ = [("cb", wintypes.DWORD),
                    ("DeviceName", wintypes.WCHAR * 32),
                    ("DeviceString", wintypes.WCHAR * 128),
                    ("StateFlags", wintypes.DWORD),
                    ("DeviceID", wintypes.WCHAR * 128),
                    ("DeviceKey", wintypes.WCHAR * 128)]
    i = 0
    while True:
        d = DISPLAY_DEVICE()
        d.cb = ctypes.sizeof(DISPLAY_DEVICE)
        if not user32.EnumDisplayDevicesW(None, i, ctypes.byref(d), 0):
            break
        if d.StateFlags & 0x1:  # DISPLAY_DEVICE_ATTACHED_TO_DESKTOP
            devs.append(d.DeviceName)
        i += 1
    return devs


def build_ramp(lift: float, gamma: float, keep_white=True):
    """抬暗部曲线：out = lift + (1-lift) * x^gamma（x=输入/65535）"""
    lift = max(0.0, min(0.45, lift))
    gamma = max(0.45, min(1.0, gamma))
    r = GammaRamp()
    for i in range(RAMP_SIZE):
        x = i / (RAMP_SIZE - 1)
        y = lift + (1 - lift) * (x ** gamma)
        if keep_white and i == RAMP_SIZE - 1:
            y = 1.0
        v = int(round(max(0.0, min(1.0, y)) * 65535))
        r.red[i] = r.green[i] = r.blue[i] = v
    return r


def identity_ramp():
    r = GammaRamp()
    for i in range(RAMP_SIZE):
        v = int(round(i / (RAMP_SIZE - 1) * 65535))
        r.red[i] = r.green[i] = r.blue[i] = v
    return r


def get_dc(device=None):
    if device:
        h = gdi32.CreateDCW("DISPLAY", device, None, None)
        return h, True
    return user32.GetDC(None), False


def release_dc(h, created):
    if created:
        gdi32.DeleteDC(h)
    else:
        user32.ReleaseDC(None, h)


def apply_ramp(ramp, all_displays=True):
    ok_any = False
    targets = list_displays() if all_displays else [None]
    for dev in targets:
        h, created = get_dc(dev)
        if not h:
            continue
        ok = bool(gdi32.SetDeviceGammaRamp(h, ctypes.byref(ramp)))
        release_dc(h, created)
        print(f"  {dev or '主显示器'}: " + ("成功" if ok else "失败（驱动拒绝或权限不足）"))
        ok_any = ok_any or ok
    return ok_any


def read_ramp(device=None):
    h, created = get_dc(device)
    if not h:
        return None
    r = GammaRamp()
    ok = bool(gdi32.GetDeviceGammaRamp(h, ctypes.byref(r)))
    release_dc(h, created)
    return r if ok else None


def show():
    r = read_ramp()
    if r is None:
        print("读取失败"); return
    samples = [0, 16, 32, 64, 128, 192, 255]
    print("当前 Gamma Ramp 采样（红通道，0~65535）：")
    for i in samples:
        print(f"  输入 {i:3d} → {r.red[i]:5d}  ({r.red[i]/65535*100:5.1f}%)")


def clamp(v, lo, hi):
    return max(lo, min(hi, v))


def gui():
    """极简界面：一个开关。点 × 最小化到系统托盘，不退出。"""
    import atexit
    import queue
    import threading
    import time
    import tkinter as tk

    # 托盘依赖：pystray + Pillow
    try:
        import pystray
        from PIL import Image, ImageDraw
        TRAY_LIBS = True
    except Exception:
        TRAY_LIBS = False

    # 单实例：托盘常驻后重复双击 bat 会开出多个实例互相抢亮度，这里直接叫出已有窗口
    try:
        _hwnd = user32.FindWindowW(None, "暗部增强")
        if _hwnd:
            user32.ShowWindow(_hwnd, 9)          # SW_RESTORE
            user32.SetForegroundWindow(_hwnd)
            return
    except Exception:
        pass

    def tray_image(on: bool):
        """画托盘图标：深色底 + 太阳 + 地平线；开启时琥珀色，关闭时灰色。"""
        img = Image.new("RGBA", (64, 64), (0, 0, 0, 0))
        d = ImageDraw.Draw(img)
        d.rounded_rectangle((2, 2, 61, 61), radius=14, fill=(30, 32, 40, 255))
        disc = (255, 193, 61, 255) if on else (124, 130, 144, 255)
        d.ellipse((14, 12, 50, 48), fill=disc)
        d.rectangle((10, 42, 54, 54), fill=(30, 32, 40, 255))
        d.line((10, 48, 54, 48), fill=disc, width=3)
        return img

    root = tk.Tk()
    root.title("暗部增强")
    root.geometry("360x272")
    root.resizable(False, False)
    root.attributes("-topmost", True)

    state = {"on": False}
    lift_var = tk.DoubleVar(value=load_lift_setting())
    gamma_var = tk.DoubleVar(value=0.85)
    tray = {"icon": None, "ok": False}

    title = tk.Label(root, text="暗部场景增强", font=("Microsoft YaHei", 14, "bold"))
    title.pack(pady=(16, 2))
    hint = tk.Label(
        root,
        text="点右上角 × 会缩到右下角托盘（双击图标恢复）" if TRAY_LIBS
        else "阴暗角落看得更清楚（关闭窗口自动还原）",
        font=("Microsoft YaHei", 9), fg="#888",
    )
    hint.pack()

    toggle = tk.Button(root, text="○  关闭", font=("Microsoft YaHei", 18, "bold"),
                       width=14, height=2, relief="ridge", bg="#e9e9e9")
    toggle.pack(pady=14)

    tk.Label(root, text="强度", font=("Microsoft YaHei", 10)).pack()
    scale = tk.Scale(root, variable=lift_var, from_=0.04, to=0.30, resolution=0.01,
                     orient="horizontal", length=280, showvalue=True,
                     font=("Microsoft YaHei", 9))
    scale.pack()
    def save_and_apply(*_):
        save_lift_setting(lift_var.get())
        apply_now()

    scale.bind("<ButtonRelease-1>", save_and_apply)
    scale.bind("<B1-Motion>", lambda e: apply_now())
    scale.bind("<KeyRelease>", save_and_apply)

    def restore():
        apply_ramp(identity_ramp())
        state["on"] = False

    def apply_now(*_):
        if not state["on"]:
            return
        ok = apply_ramp(build_ramp(lift_var.get(), gamma_var.get()))
        if not ok:
            toggle.config(text="×  失败", bg="#ffd9d9", fg="#900")

    def sync_tray():
        """让托盘图标和菜单文字跟随开关状态。"""
        icon = tray["icon"]
        if icon is None:
            return
        try:
            icon.icon = tray_image(state["on"])
            icon.update_menu()
        except Exception:
            pass

    def toggle_click():
        if state["on"]:
            restore()
            toggle.config(text="○  关闭", bg="#e9e9e9", fg="#000")
        else:
            state["on"] = True
            apply_now()
            toggle.config(text="●  已开启", bg="#c8f7c5", fg="#0a5")
        sync_tray()

    toggle.config(command=toggle_click)

    def show_window(*_):
        root.deiconify()
        root.lift()
        try:
            root.attributes("-topmost", True)
            root.focus_force()
        except Exception:
            pass

    def hide_window():
        root.withdraw()
        icon = tray["icon"]
        if icon is not None:
            try:
                icon.notify("已缩到右下角托盘，双击图标恢复；右键可还原并退出", "暗部增强")
            except Exception:
                pass

    def quit_app(*_):
        try:
            save_lift_setting(lift_var.get())
            restore()
        finally:
            icon = tray["icon"]
            if icon is not None:
                try:
                    icon.stop()
                except Exception:
                    pass
            try:
                root.destroy()
            except Exception:
                pass

    def on_close():
        # 有托盘 → 收起来继续生效；没有托盘 → 退回原来的"还原并退出"
        if tray["ok"]:
            hide_window()
        else:
            quit_app()

    # 托盘菜单在自己的线程里，统一投递到主线程执行，避免 Tkinter 跨线程报错
    jobs = queue.Queue()

    def on_tray_show(icon=None, item=None):
        jobs.put("show")

    def on_tray_toggle(icon=None, item=None):
        jobs.put("toggle")

    def on_tray_quit(icon=None, item=None):
        jobs.put("quit")

    def drain_jobs():
        try:
            while True:
                cmd = jobs.get_nowait()
                if cmd == "show":
                    show_window()
                elif cmd == "toggle":
                    toggle_click()
                elif cmd == "quit":
                    quit_app()
                    return
        except queue.Empty:
            pass
        root.after(120, drain_jobs)

    if TRAY_LIBS:
        try:
            menu = pystray.Menu(
                pystray.MenuItem("显示面板", on_tray_show, default=True),
                pystray.MenuItem(
                    lambda item: "关闭增强" if state["on"] else "开启增强",
                    on_tray_toggle,
                ),
                pystray.Menu.SEPARATOR,
                pystray.MenuItem("还原并退出", on_tray_quit),
            )
            icon = pystray.Icon("shadow_boost", tray_image(False), "暗部增强", menu)
            tray["icon"] = icon
            try:
                icon.run_detached()          # 与 tkinter 主循环共存
            except Exception:
                threading.Thread(target=icon.run, daemon=True).start()

            for _ in range(40):              # 最多等 2 秒确认托盘图标已就绪
                if getattr(icon, "visible", False):
                    tray["ok"] = True
                    break
                time.sleep(0.05)
        except Exception:
            tray["ok"] = False
            tray["icon"] = None

    root.protocol("WM_DELETE_WINDOW", on_close)
    root.bind("<Escape>", lambda e: on_close())
    atexit.register(restore)          # 进程退出（含异常）也还原

    restore()                         # 启动时先确保是默认状态
    root.after(120, drain_jobs)
    root.mainloop()


def main():
    ap = argparse.ArgumentParser(description="暗部增强（Gamma Ramp 方式）")
    sub = ap.add_subparsers(dest="cmd", required=True)
    a = sub.add_parser("apply"); a.add_argument("--lift", type=float, default=0.10)
    a.add_argument("--gamma", type=float, default=0.85)
    sub.add_parser("reset")
    sub.add_parser("show")
    sub.add_parser("gui")
    args = ap.parse_args()

    if args.cmd == "apply":
        print(f"应用：抬暗部 {args.lift}，伽马 {args.gamma}")
        apply_ramp(build_ramp(args.lift, args.gamma))
        show()
    elif args.cmd == "reset":
        print("还原为默认曲线"); apply_ramp(identity_ramp()); show()
    elif args.cmd == "show":
        show()
    elif args.cmd == "gui":
        gui()


if __name__ == "__main__":
    main()
