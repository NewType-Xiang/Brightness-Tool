# Shadow Boost / 暗部增强

一个仅适用于 Windows 的轻量显示增强工具。它通过 Windows `SetDeviceGammaRamp` 调整显示输出 Gamma Ramp，抬高暗部亮度，便于观察游戏或视频中的阴暗区域。

它不会注入游戏进程，也不会修改游戏内存或游戏文件。

## 功能

- 图形界面实时开关暗部增强
- 0.04 到 0.30 的增强强度调节
- 多显示器 Gamma Ramp 应用
- 系统托盘常驻，关闭窗口不会中断增强
- 退出时自动恢复默认曲线
- 命令行应用、重置和查看当前 Gamma Ramp

## 系统要求

- Windows 10 或 Windows 11
- Python 3.9 或更高版本
- 支持 `SetDeviceGammaRamp` 的显卡驱动和显示输出

部分 HDR 模式、独占全屏游戏、显卡驱动或显示器可能忽略或覆盖 Gamma Ramp。

## 安装与启动

```powershell
git clone https://github.com/YOUR_NAME/shadow-boost.git
cd shadow-boost
py -m pip install -r requirements.txt
```

双击 `启动.bat`，或运行：

```powershell
py shadow_boost.py gui
```

## 命令行

```powershell
# 应用增强
py shadow_boost.py apply --lift 0.10 --gamma 0.85

# 恢复默认 Gamma Ramp
py shadow_boost.py reset

# 查看当前曲线采样
py shadow_boost.py show
```

## 使用说明

- 点击主按钮开启或关闭增强。
- 拖动“强度”滑块可实时调整效果。
- 点击窗口右上角关闭按钮后，程序会缩至系统托盘。
- 右键托盘图标可开关增强，或选择“还原并退出”。
- 程序正常退出时会恢复默认 Gamma Ramp。

如果程序异常终止后显示仍异常，可运行：

```powershell
py shadow_boost.py reset
```

## 项目结构

```text
shadow_boost.py  主程序
启动.bat         Windows 启动脚本
requirements.txt Python 依赖
图标.jpg         原始图标
图标.ico         Windows 多尺寸图标
```

`settings.json` 是运行时生成的本地配置，不提交到仓库。

## 安全与限制

- 本工具只修改当前 Windows 会话的显示 Gamma Ramp。
- 某些游戏、HDR、驱动重置、休眠或显示模式切换会覆盖效果。
- 使用增强后判断图片或视频颜色可能不准确，进行图像处理前请先关闭。

## 开源许可

[MIT License](LICENSE)

