@echo off
setlocal
cd /d "%~dp0"

rem Prefer Python Launcher, then pythonw/python from PATH.
where pyw >nul 2>nul && (start "" pyw -3 "%~dp0shadow_boost.py" gui & exit /b 0)
where pythonw >nul 2>nul && (start "" pythonw "%~dp0shadow_boost.py" gui & exit /b 0)
where py >nul 2>nul && (start "" py -3 "%~dp0shadow_boost.py" gui & exit /b 0)
where python >nul 2>nul && (start "" python "%~dp0shadow_boost.py" gui & exit /b 0)

echo Python 3 was not found. Install it from https://www.python.org/downloads/windows/
pause
exit /b 1
